import ptlib
import os

ver = '1.0-APLHA'

ramFile = ''

def setRam(path):
    global ramFile
    if ptlib.exists(path):
        ramFile = path
    else:
        print('Cant Find RAMFile: ' + path)
def ramSize():
    if ramSetUp:
        return os.path.getsize(ramFile)
    else:
        print('ERROR: Ram System Not Set Up! Exiting')
        exit()

def createRam(path):
    ptlib.createFile(path, 512)

def getRam(index):
    #index starts at 0
    with open(ramFile, 'rb') as f:
        out = f.read()[index]
    return out

def readRam():
    global ramFile
    with open(ramFile, 'rb') as f:
        out = f.read()
    return out

def writeRam(index, value):
    global ramFile
    data = list(readRam())
    if int(index) < 0:
        print('INVALID INDEX: ' + str(index))
    else:
        data[int(index)] = value
        with open(ramFile, 'wb') as f:
            f.write(bytearray(data))
