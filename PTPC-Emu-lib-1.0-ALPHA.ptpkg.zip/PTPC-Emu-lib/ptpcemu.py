import ptlib
import os

ver = '1.0-APLHA'

ramFile = ''

def setRam(path):
    global ramFile
    if ptlib.exists(path):
        ramFile = path
    else:
        print('Cant Find RAMFile: ' + path)
def ramSize():
    if ramSetUp:
        return os.path.getsize(ramFile)
    else:
        print('ERROR: Ram System Not Set Up! Exiting')
        exit()

def createRam(path):
    ptlib.createFile(path, 65536)

def getRam(index):
    #index starts at 0
    with open(ramFile, 'rb') as f:
        out = f.read()[index]
    return out

def readRam():
    global ramFile
    with open(ramFile, 'rb') as f:
        out = f.read()
    return out

def writeRam(index, value):
    global ramFile
    data = list(readRam())
    if int(index) < 0:
        print('INVALID INDEX: ' + str(index))
    else:
        try:
            data[int(index)] = value
            with open(ramFile, 'wb') as f:
                f.write(bytearray(data))
        except KeyboardInterrupt:
            data[int(index)] = value
            with open(ramFile, 'wb') as f:
                f.write(bytearray(data))            

def dec2hex8(int8):
    if int8 == 0:
        out = '0x00'
    elif len(hex(int8)) < 4:
        out = '0x0' + hex(int8).lstrip('0x').upper()
    else:
        out = '0x' + hex(int8).lstrip('0x').upper()
    return out

def dec2hex16(int16):
    if int16 == 0:
        out = '0x0000'
    elif len(hex(int16)) < 6:
        out = '0x00' + hex(int16).lstrip('0x').upper()
    else:
        out = '0x' + hex(int16).lstrip('0x').upper()
    return out

def dec8dec82hex16(int81, int82):
    if int81 == 0:
        out1 = '0x00'
    elif len(hex(int81)) < 4:
        out1 = '0x0' + hex(int81).lstrip('0x').upper()
    else:
        out1 = '0x' + hex(int81).lstrip('0x').upper()
    
    if int82 == 0:
        out2 = '00'
    elif len(hex(int82)) < 4:
        out2 = '0' + hex(int82).lstrip('0x').upper()
    else:
        out2 = hex(int82).lstrip('0x').upper()
    out = out1 + out2
    return out

def hex82dec(hex8):
    if hex8[0:1] == '0x' or hex8[0:1] == '0X':
        out = int(hex8.lstrip('0x'), 16)
    else:
        out = int(hex8, 16)
    return out()

def filterHex(hex1):
    if hex1[1] == 'x' or hex1[1] == 'X':
        out = hex1.lstrip('0x')
    else:
        out = hex1
    return out

def hex8add(hex81, hex82):
    int1 = hex82dec(hex81)
    int2 = hex82dec(hex82)
    out = dec2hex(int1 + int2)
    return out

def hex8hex82hex16(hex81, hex82):
    hex1 = filterHex(hex81)
    hex2 = filterHex(hex82)
    out = hex1 + hex2
    return out
    
    


